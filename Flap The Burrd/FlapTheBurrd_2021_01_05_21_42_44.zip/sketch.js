// Game objects
let playerBird;
let pillar1;
let pillar2;
let pillar3;

// Game States
let showText;
let collision;
let started;

// Buttons
let replayButton;
let playButton

// Assets
let sky;
let sky2;
let skyPos;
let sky2Pos;
let grnd;
let grnd2;
let grndPos;
let grnd2Pos;
let birdSprite;

// Score
let scoreboard;
let finalScore;
let scoreCounted;
let score;


function preload() {
  myFont = loadFont('font.ttf');
  sky = loadImage('sky.png');
  sky2 = loadImage('sky.png');
  grnd = loadImage('grnd.png');
  grnd2 = loadImage('grnd.png');
  birdSprite = loadImage('bird.png');
  scoreboard = loadImage('scoreboard.png');
}

function setup() {
  // Create canvas and set framerate
  createCanvas(600, 400);
  frameRate(45);
  textFont(myFont);
  
  // Initialize replay button
  replayButton = createButton('Try Again');
  replayButton.position(-400,-400);
  replayButton.size(100,20);
  
  // Initialize play button
  playButton = createButton('Play Now');
  playButton.position(width/2-55,height/2+32);
  playButton.size(100,20);
  
  // Create game objects
  playerBird = new bird();
  pillar1 = new pillar(width);
  pillar2 = new pillar(width/3);
  pillar3 = new pillar(2*width/3);
  
  // Initialize sky
  skyPos = 0;
  sky2Pos = 980*3/4-5;
  grndPos = 0;
  grnd2Pos = 550;
  
  // Show information text? 
  textSize(12);
  showText = false;
  
  // Initialize score
  score = 0;
  scoreCounted = false;
  
  // Initialize Game
  collision = true;
  started = false;
  
}

function draw() {
  background(15,135,255); //This is necessary to hide the seam in the sky
  updateBG();
  drawBG();

  if (!collision) { // Game Loop
    pillar1.update();
    pillar2.update();
    pillar3.update();
    playerBird.update();
    printScore();
  }
  else {
    if (!scoreCounted) {
      finalScore = score;
      scoreCounted = true;
    }
    pillar1.update();
    pillar2.update();
    pillar3.update();
    
    if (started) { // Game Over screen
      image(scoreboard,width/2-165,height/2-53,scoreboard.width*2,scoreboard.height*2.5);
      textSize(32);
      fill(0)
      stroke(0);
      text('GAME OVER',width/2-146,height/2+3);
      fill(255,0,0)
      stroke(255,0,0);
      text('GAME OVER',width/2-147,height/2);
      fill(0)
      stroke(0)
      textSize(15)
      text('SCORE : '+finalScore,width/2-65,height/2+24);
      textSize(12)
      
      replayButton.position(width/2-55,height/2+32);
      replayButton.mousePressed(reset);
    }
    else { // Start screen
      image(scoreboard,width/2-167,height/2-53,scoreboard.width*2.2,scoreboard.height*2.5);
      textSize(32);
      fill(0)
      stroke(0);
      text('FRESH BIRD',width/2-144,height/2+3);
      fill(139,69,19)
      stroke(139,69,19);
      text('FRESH BIRD',width/2-145,height/2);
      fill(0)
      stroke(0)
      textSize(12)
      text('Controls: SpaceBar to jump',width/2-125,height/2+22);
      playButton.position(width/2-40,height/2+32);
      playButton.mousePressed(startGame);
    }
    

  }
  
  updateFG();
  drawFG();
}

function keyPressed() {
  if (keyCode === 32) {
    playerBird.jump();
  }
}

function startGame() {
  started = true;
  reset();
}

function updateBG() {
  skyPos -= 0.5;
  if (skyPos+980*3/4 < 0) {
    skyPos = 980*3/4-5;
  }
  sky2Pos -= 0.5;
  if (sky2Pos < -(980*3/4)) {
    sky2Pos = 980*3/4-5;
  }
}

function drawBG() {
  image(sky,skyPos,-45,sky.width*3/4,sky.height*3/4);
  image(sky2,sky2Pos,-45,sky2.width*3/4,sky2.height*3/4);
}

function updateFG() {
  grndPos -= 2;
  if (grndPos+550 < 0) {
    grndPos = 550;
  }
  grnd2Pos -= 2;
  if (grnd2Pos+550 < 0) {
    grnd2Pos = 550;
  }
}

function drawFG() {
  image(grnd,grndPos,380,grnd.width,grnd.height);
  image(grnd2,grnd2Pos,380,grnd.width,grnd.height);
}

function printScore() {
  textSize(11);
  image(scoreboard,470,5,scoreboard.width*3/4,scoreboard.height*3/4);
  fill(0);
  stroke(0);
  text('SCORE : '+score,481,28);
  fill(139,69,19);
  stroke(139,69,19);
  text('SCORE : '+score,480,26);
}

function reset() {
  playerBird.setPos(200);
  playerBird.setVel(0);
  pillar1.setPos(width);
  pillar2.setPos(width/3);
  pillar3.setPos(2*width/3);
  score = 0;
  replayButton.position(-400,-400);
  playButton.position(-400,-400);
  collision = false;
}



class bird {
  
  constructor() {
    // Constants
    this.x = 50;  // xPos
    this.r = 8;   // bird radius
    this.g = 0.5;  // gravity acc
    // Variables
    this.y = 200; // yPos
    this.v = 0;   // velocity
    
  }
  
  setPos(yPos) {
    this.y = yPos;
  }
  
  setVel(vel) {
    this.v = vel;
  }
  
  draw() {
    let angle
    if (this.v<0) {
      angle=max(-PI/2,PI*(this.v/45))
    }
    else {
      angle=min(PI/2,PI*(this.v/60))
    }
    /*fill(154,205,50);
    stroke(0);
    ellipse(this.x,this.y,this.r*2);
    fill(255,255,0);
    ellipse(this.x+this.r*cos(angle),this.y+this.r*sin(angle),this.r);
    noStroke();
    fill(154,205,50)
    ellipse(this.x,this.y,2*this.r-2);
    stroke(0);
    fill(0);
    ellipse(this.x+0.4*this.r*sin(angle),this.y-0.4*this.r*cos(angle), this.r/5);
    //line(this.x+this.r-1,this.y,this.x+1.5*this.r,this.y)
    line(this.x+this.r*cos(angle),this.y+this.r*sin(angle),this.x+1.5*this.r*cos(angle),this.y+1.5*this.r*sin(angle))*/
    /*noStroke()
    fill(255,0,0,100);
    ellipse(this.x,this.y,this.r*2);*/
    push()
    translate(this.x,this.y)
    rotate(angle);
    image(birdSprite,-22,-16,birdSprite.width/3,birdSprite.height/3);
    pop()
    
    
    if (showText) {
      text('Bird Pos: '+this.y,15,this.y+this.r+12);
      text('Bird Vel: '+this.v,15,this.y+this.r+26);
    }
  }
  
  update() {
    this.edgeCheck();
    this.v += this.g;
    this.draw()
  }
  
  edgeCheck() {
    this.y += this.v;
    if (this.y > 385-this.r) {
      this.y=385-this.r;
      this.v=0;
      collision = true;
    }
    if (this.y < 0) {
      this.y = this.r;
      this.v = 0;
    }
    if (abs(this.v) > 25) {
      if (this.v > 0) {this.v = 25;}
      else {this.v = -25;}
    }
  }
  
  jump() {
    this.v -= 10;
  }
  
  getPos() {
    return this.y;
  }
  
  getR() {
    return this.r;
  }
}

class pillar {
  
  constructor(xPos) {
    // Constants
    this.birdSize = playerBird.getR();
    this.v = 2;
    this.width = 30;
    // Variables
    this.holeH = random(this.birdSize*4,height-this.birdSize*12);
    this.holeS = random(this.birdSize*6,this.birdSize*12);
    this.x = xPos;
    this.draw();
  }
  
  setPos(xPos) {
    this.x = xPos;
  }
  
  draw() {
    // Main Pipe
    stroke(34,139,34);
    fill(34,139,34);
    rect(this.x+4,0,this.width-8,this.holeH); // Upper Pipe
    rect(this.x+4,this.holeH+this.holeS,this.width-8,height-(this.holeH+this.holeS));
    // Highlights
    stroke(50,205,50);
    fill(50,205,50);
    rect(this.x+7,0,6,this.holeH-20); // Upper Pipe
    rect(this.x+7,this.holeH+this.holeS+20,6,height-this.holeH-20); // Lower Pipe
    // Shadows
    stroke(0,100,0);
    fill(0,100,0);
    rect(this.x+4,this.holeH+this.holeS+20,this.width-8,4);
    rect(this.x+22,0,4,this.holeH); // Upper Pipe
    rect(this.x+22,this.holeH+this.holeS,4,height-(this.holeH+this.holeS)); // Lower Pipe
    // Pipe Mouths
    stroke(34,139,34);
    fill(34,139,34);
    rect(this.x,this.holeH-20,this.width,20);
    rect(this.x,this.holeH+this.holeS,this.width,20);
    // Pipe Mouth Shadows
    stroke(0,100,0);
    fill(0,100,0);
    rect(this.x,this.holeH-2,this.width,2);
    rect(this.x,this.holeH+this.holeS,this.width,2);
    rect(this.x+this.width-8,this.holeH-20,8,20)
    rect(this.x+this.width-8,this.holeH+this.holeS,8,20)
    // Pipe Mouth Highlights
    stroke(50,205,50);
    fill(50,205,50);
    rect(this.x,this.holeH-20,10,16);
    rect(this.x,this.holeH+this.holeS+3,10,17);
    // Hole
    /*fill(173,216,230);
    stroke(173,216,230);
    rect(this.x,this.holeH,this.width,this.holeS);*/
    // Additional info text
    if (showText) {
      fill(0)
      stroke(0)
      text('Hole height: '+round(this.holeH),this.x-30,this.holeH);
      text('Rel. hole size: '+round(this.holeS)/this.birdSize,this.x-30,this.holeH+13);
    }
  }
  
  update() {
    this.checkEdge();
    this.x -= this.v;
    this.draw();
    this.checkCollision();
  }
  
  checkEdge() {
    if (this.x < -this.width) {
      score += 1;
      this.x = width+this.width;
      this.holeH = floor(random(this.birdSize*2,height-this.birdSize*12));
      this.holeS = random(this.birdSize*6,this.birdSize*12);
    }
  }
  
  checkCollision() {
    if ((this.x>(50-this.birdSize-this.width))&&(this.x<(50+this.birdSize))) {
      if (((playerBird.getPos()-this.birdSize)<this.holeH)||((playerBird.getPos()+this.birdSize)>(this.holeH+this.holeS))) {
        collision = true;
      }
    }
  }
  
}